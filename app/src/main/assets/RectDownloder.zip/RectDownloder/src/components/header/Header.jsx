import React from "react";
import MainBox from "../videoPage/mainBox";

function Header() {
    return (
        <div className="containerHeader">
            <div className="headerTitle">
                <h1>Youtube Downloader</h1>
            </div>
        </div>
    )
}

export default Header;