function myapp(args){
	if(args !== 200)
	alert("Hello")
	else
	console.log("mm")
}
myapp()
